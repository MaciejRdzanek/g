﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzujnikCzadu.ModelDanych
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("ilosc baterii to ");
            BateriaCzujnika bateria = new BateriaCzujnika("Toshiba", 200);
            Console.WriteLine("Producent i ilosc baterii to:" + bateria.CzujnikCzadu());
        }
    
    internal class BateriaCzujnika
    {
        private string nazwa_producenta;
        private int czas_działania;
        private decimal zużycie_bateri;


        public string Nazwa_producenta
        {
            get
            {
                return nazwa_producenta;
            }
        }
        DateTime Today { get; }


        public int Czas_działania
        {
            get
            {
                return czas_działania;
            }
        }
         
            


            public BateriaCzujnika(string nazwaproducenta, int czasdziałania)
        {
            this.nazwa_producenta = nazwa_producenta;
            this.czas_działania = czas_działania;
            this.zużycie_bateri = zużycie_bateri;
        }


        public decimal Zużycie_bateri
        {
            get
            {
                return zużycie_bateri;
            }
        }


    }


        public double CzujnikCzadu()
        { 
            DateTime data_zamontowania = new DateTime(2022, 10, 10);
            DateTime data_wycz = data_zamontowania.AddDays(czasDziałania);
            DateTime data_teraz = DateTime.Now;
            double procent_baterii = (data_teraz - data_wycz).TotalDays;
            int Iproc = 100 / czasDziałania;
            double procent_bateriiI = Iproc * procent_baterii; return procent_baterii; if (procent_baterii > 0)
            {
                Console.WriteLine("Bateria wynosi " + procent_baterii);
            }
            else Console.WriteLine("Bateria wynosi 0%");
        }























    }
}


  